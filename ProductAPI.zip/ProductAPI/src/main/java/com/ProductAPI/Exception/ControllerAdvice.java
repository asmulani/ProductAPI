package com.ProductAPI.Exception;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler; 
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import jakarta.servlet.http.HttpServletRequest;
@org.springframework.web.bind.annotation.ControllerAdvice
public class ControllerAdvice {
@ExceptionHandler(ResourceNotFoundException.class)
@ResponseStatus(value = HttpStatus.NOT_FOUND)
@ResponseBody MyExceptionFormat handleResourceNotFoundException(ResourceNotFoundException resource, HttpServletRequest request){
MyExceptionFormat myresponse=new MyExceptionFormat(); 
myresponse.setMassage (resource.getMessage());
myresponse.setUrl(request.getRequestURI()); 
return myresponse;
}
}