package com.ProductAPI.Exception;
public class MyExceptionFormat {
String massage;
String url;
public String getMassage() {
return massage;
}
public void setMassage(String massage) {
this.massage = massage;
}
public String getUrl() {
return url;
}
public void setUrl(String url) {
this.url = url;
}
}