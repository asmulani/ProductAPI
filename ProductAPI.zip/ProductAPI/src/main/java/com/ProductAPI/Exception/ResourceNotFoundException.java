package com.ProductAPI.Exception;
public class ResourceNotFoundException extends RuntimeException {
public ResourceNotFoundException() {
// TODO Auto-generated constructor stub
}
public ResourceNotFoundException(String massage) {
super(massage);
// TODO Auto-generated constructor stub
}
}