package com.ProductAPI.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ProductAPI.Entity.Product;
import com.ProductAPI.Exception. ResourceNotFoundException;
import com.ProductAPI.Repository.ProductRepository;
@Service
public class ProductService {
@Autowired
private ProductRepository prepo;
public Product addproduct(Product pro) {
return prepo.save(pro);
}
public Product getByID(int id) throws ResourceNotFoundException {
Product p2=null;
try {
p2=prepo.findById(id).orElse(p2);
}
catch (Exception e) {
e.printStackTrace();
}
if(p2==null)
throw new ResourceNotFoundException("Product not exist");
else
return p2;
}
public Product updateByld(Product pro, int id) throws ResourceNotFoundException {
Product p1=null;
try {
p1=prepo.findById(id).get();
}
catch (Exception e) {
e.printStackTrace();
}
if(p1 ==null) {
throw new ResourceNotFoundException("Product not exist of this id");
}
else
return prepo.save(pro);
}
public void deleteProduct(int id) throws ResourceNotFoundException {
Product p1=prepo.findById(id).orElseThrow()-> new ResourceNotFoundException("Product not exist of this id"); 
prepo.deleteById(id);
}
}